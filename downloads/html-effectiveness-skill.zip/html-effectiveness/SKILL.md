---
name: html-effectiveness
description: Generate single-file HTML instead of markdown for any document a human will read — plans, specs, PR writeups, code reviews, design systems, status/incident reports, research explainers, slide decks, comparisons, exploration grids, SVG diagrams, throwaway editors — and for surfacing unknowns — blindspot passes, assumption maps, interviews, deviation logs, buy-in docs, pre-merge quizzes. Use when the user asks for an HTML file/artifact, a plan, a comparison, a report, a diagram, a quick editor, asks "what don't you know" / "what are you assuming" / "did you deviate", or wants any readable deliverable over ~100 lines. Not for chat replies, commit messages, or README/CLAUDE.md edits.
---

# html-effectiveness

Markdown stops working past ~100 lines — the human skims and approves on faith. A single self-contained `.html` file carries tables, color, SVG diagrams, code, and interaction; opens from disk or an S3 link; and gets read in five minutes instead of skimmed in thirty seconds. The 2–4x token cost buys a closed review loop. Full argument: `reference/why-html.md` (read once when forming intuition; skip on routine tasks). Usually "make a HTML file" is enough — the patterns below are a head start, not a gate.

## Choosing the artifact form

Don't "make HTML" — pick the form that matches what the human is about to **do** with it. Ask one question: *what does the user do after opening this file?* First match wins:

| User is about to… | Archetype | Reference | Must have | Export |
|---|---|---|---|---|
| Pick between alternatives | Exploration grid / design fan-out | 01, 02, 28 | 3–6 variants, tradeoff label on each | copy choice as prompt |
| Approve future work (operator) | Tweakable plan | 16, 26 | decisions-likely-to-change first with toggleable alternatives, mechanical work collapsed, gotchas | optional |
| Approve future work (stakeholder) | Buy-in doc | 23 | demo first, objection→evidence pairs, named sign-offs | copy decision |
| Understand a change | Annotated PR explainer | 03, 17 | real diff, margin notes, severity colors | copy findings |
| Understand a system | SVG diagram / explainer | 04, 10, 13–15 | inline SVG, legend, annotated hot path | none |
| Do work in the UI | Custom editor | 18, 19 | pre-sorted real data, live constraint warnings | **mandatory** |
| Pick exact values | Prompt tuner / sliders | 20, 07 | live preview, counters | **mandatory** |
| Answer what the agent doesn't know | Unknowns map / blindspot pass | 21 | assumptions + confidence, questions + defaults, blast-radius order | **mandatory** — copy answers as prompt |
| Judge silent changes mid-build | Deviation log | 22 | planned→actual→why rows, per-row keep/revert verdict | **mandatory** — copy verdicts as prompt |
| Confirm it's actually done | Pre-merge quiz / verification | 24 | claim→evidence, scored quiz, fail links back to skimmed sections | copy failures as prompt |
| Set visual taste once | Design-system sheet | 05, 06 | real swatches, live components in every state | the file itself is the export |

Rules of the table:

- **If the human edits, drags, toggles, or answers anything in the artifact, a copy-out button is mandatory.** Read-only artifacts (diagram, explainer) don't need one. The export assembles the human's *next prompt* for them — reactions in, paste-ready text out.
- **The trust rows are agent-initiated.** Offer an unknowns map or interview before ambiguous work in unfamiliar territory; keep a deviation log while executing an approved plan (surprise → pick the conservative option, log it, keep going); offer the pre-merge quiz after. Don't wait to be asked. Full catalog of all 11 unknowns patterns with verbatim prompts: `reference/unknowns-workflow.md`; live templates for every one: 21 (blindspot/unknowns map), 22 (deviation log), 23 (buy-in doc), 24 (pre-merge quiz), 25 (interview), 26 (tweakable plan), 27 (semantics map), 28 (design directions), 29 (throwaway mock), 30 (brainstorm), 31 (teach-me explainer).
- Two intents in one ask → two files, linked. Don't build a hybrid nobody can scan.
- No row fits → default to the closest read-only form and say which row you almost picked.

## How to use a pattern

1. **Pick** — match the ask to a row above; `reference/MANIFEST.md` is the full pattern lookup.
2. **Look at the gold standard** — Read the matching screenshot in `assets/screenshots/` (`main-NN-*.jpg` / `unknowns-NN-*.jpg`; index in `reference/visual-quality-spec.md`). One look at Thariq's actual output calibrates finish quality better than any description. Then Read the matching `reference/NN-*.html` for the code idioms.
3. **Hold the design contract** — `reference/visual-quality-spec.md` is binding: the Acme palette (ivory page, one clay accent, olive success), three-role typography (serif for humans, caps-mono for metadata, sans for explanation), labeled micro-row card anatomy, stat strips, 7–11 lived-in items with file paths and numbers (never 2–4 thin ones), live-rendered components, and a closing decision/export section.
4. **Write fresh** — a new single-file HTML adapted to the user's content. Borrow the *structure* and *interaction model*, never the literal copy.
5. **Self-check** — run the fast pass in `reference/artifact-rubric.md` before delivering; full rubric when the artifact is interactive or stakeholder-facing.

## Workflow: the web of HTML files

Real problems are a *web* of artifacts, not one document: **explore** (4–6 approaches in a grid) → **expand** the winner → **plan** (tweakable plan) → **execute** in a fresh session that reads the artifacts, keeping a deviation log → **verify** (quiz/verification artifact reads the same files). Each artifact is the handoff unit between sessions; pass the files forward, don't summarize them into chat.

## Matching the user's taste

For a specific brand: point at the user's codebase once, produce a durable `design-system.html` (tokens, type scale, spacing, component examples), then Read it as the visual contract on every future artifact. Cheapest taste-transfer in the stack. For general aesthetic floor, pair with the `frontend-design` skill.

## Output rules

- Write a `.html` file; filename short, kebab-case, descriptive (`api-caching-plan.html`, not `output.html`).
- Top of file: `<!doctype html>`, `<meta charset="utf-8">`, viewport meta, and a `<title>` naming this artifact.
- Inline CSS and JS only. No CDN, no remote stylesheets or fonts, no frameworks. Must open from disk.
- SVG for diagrams. Always. Never ASCII, never unicode-block "colors".
- Mobile-responsive: flexbox/grid; wide tables scroll in their own container.
- Match information density to the content — don't pad to look comprehensive.
- No emoji unless the user's content invites it.
- Footer attribution when adapting a pattern: `Pattern adapted from github.com/thariqs/html-effectiveness`.

## Anti-patterns

- **Don't over-engineer.** "Make a HTML file" is usually enough; don't force a pattern-selection ritual on a simple ask.
- **Don't copy a reference file unchanged** — adapt the structure to the user's content.
- **Don't ship an editor without a copy-out button.** The button is the whole pattern.
- **Don't build a product.** Editors are throwaway: one file, one piece of data, one session.
- **Don't fake certainty in trust artifacts.** Unknowns render as unknowns; deviations get logged, not smoothed over; a quiz with giveaway questions defeats its purpose.
- **Don't add framework dependencies or remote resources** — single file, portable forever.
- **Don't render diagrams in ASCII** or unicode blocks.
- **Don't auto-invoke** for chat replies, code comments, commit messages, README/CLAUDE.md edits, or anything under ~30 lines that fits in chat. An explicit "in markdown" request overrides the HTML default — honor it.

## Reference index

- `reference/MANIFEST.md` — full pattern lookup table (31 templates) with one-line use cases.
- `reference/visual-quality-spec.md` — **binding design contract** extracted from screenshots of all 31 canonical artifacts; includes the screenshot index.
- `assets/screenshots/` — full-page captures of Thariq's actual outputs; view the matching one before writing.
- `reference/why-html.md` — the philosophy: 8 information densities, 6 motivations, FAQ, example prompts. Read once.
- `reference/unknowns-workflow.md` — the 11 "Know Your Unknowns" patterns with verbatim prompts and structural specs.
- `reference/artifact-rubric.md` — pre-delivery self-review checklist (fast pass + full).
- `reference/eval-cases.md` — trigger evals, mechanical smoke tests, proof prompts. Use when testing changes to this skill.
- `reference/index.html` — Thariq's gallery; open when nothing else clicks.

## Related skills

`frontend-design` (aesthetic floor) · `canvas-design` (static PNG/PDF) · `web-artifacts-builder` (elaborate claude.ai artifacts) · `theme-factory` / `brand-guidelines` (brand constraints).
