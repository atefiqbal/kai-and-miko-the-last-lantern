# Know Your Unknowns — the trust-artifact workflow

Companion to `why-html.md`. Source: Thariq Shihipar's "Know your unknowns" follow-up (thariqs.github.io/html-effectiveness/unknowns/). Where the main essay says *use HTML so the human reads*, this one says *use HTML to hunt what nobody knew to write in the prompt*.

**Thesis:** "The map is not the territory — the gap between them is your unknowns." Output quality is limited by the user's ability to clarify their unknowns. Johari vocabulary: **known knowns** (stated in the prompt), **known unknowns** (recognized questions, unanswered), **unknown knowns** (obvious to the user, never written down), **unknown unknowns** (not yet considered). Each artifact below is a cheap probe into one quadrant — "a cheap way to find out what you didn't know before it gets expensive to fix."

**Mechanical signature of every unknowns artifact:** the exact prompt shown at top → interactive reaction affordances in the middle (chips, checkboxes, toggles, quiz) → a copy/export button that converts the human's reactions back into the next prompt. The artifact assembles the human's reply *for* them.

**These are agent-initiated.** Don't wait to be asked. Ambiguous task in unfamiliar territory → offer a blindspot pass or interview before coding. Executing an approved plan → keep implementation notes with a deviation log. Finished planned work → offer the pre-merge quiz. Shipping to other people → buy-in doc.

## The eleven patterns

### Before implementation (finding unknowns is cheapest here)

1. **Blindspot pass** — unfamiliar territory. Scan the code, report the user's unknown unknowns as cards, each tagged by type (**Landmine / Missing concept / Convention / History / Reality gap**), each explaining the trap plus a copyable prompt-fix snippet. Final card folds every fix into "the prompt you should actually give me" with a copy button.
   > "I'm adding a new SSO auth provider to Acme but I've never touched the auth module. Do a blindspot pass: find my unknown unknowns in this part of the codebase, explain each one, and tell me how to prompt you better for the implementation."
2. **Teach me my unknowns** — unfamiliar domain. Interactive explainer that teaches the vocabulary; ends with "prompts you couldn't have written an hour ago" (copyable, using the words a professional would).
   > "I don't know what color grading is but I need to grade the Acme launch video. Teach me color grading well enough that I understand my unknown unknowns and can prompt you with real vocabulary."
3. **Fan out design directions** — taste unknowns ("reacting is easier than imagining"). 4 incompatible directions rendered live, steal/skip chips under each; footer reply-builder composes "Go with D2… Steal:… Skip:…" + copy reply.
4. **Mock before you wire** — throwaway clickable mock with fake data before real code; embedded A/B questions ("A Ship in v1 / B Hold for v1.1"); self-filling reply textarea.
5. **Brainstorm the option space** — N codebase-grounded interventions plotted cheapest → most ambitious, resonate-checkboxes assemble the reply.
6. **The interview** — ambiguity unknowns. One question at a time, **ordered by architectural blast radius**; terminates in a decisions table + ready-to-paste implementation prompt.
   > "Interview me one question at a time about anything still ambiguous in the annotation-export feature. Prioritize questions where my answer would change the architecture."
7. **Point at a reference (semantics map)** — when words run out. Before porting a reference implementation, render a per-behavior map pairing source excerpt ↔ planned equivalent with gotcha notes, edge-case tables, and a "ready to port when you are" confirmation.
8. **The tweakable plan** — plan sorted by **likelihood-of-tweaking**, not execution order. Flagged decisions with toggleable alternatives and a "weakest part of this plan" callout up top; mechanical work collapsed at the bottom ("I trust you on that part").

### During implementation

9. **Implementation notes / deviation log** — "No matter how much planning you do, unknowns lurk in the territory." Running log; entry types **Plan-confirmed / Deviation / Discovery / Todo for human**, filter tabs with counts. On surprises: pick the conservative option, log it under Deviations, keep going. Ends with "What this changes about attempt #2" bullets + copy button, and named human-decision items.
   > "Keep an implementation-notes file as you build the export feature. If you hit an edge case that forces you to deviate from the plan, pick the conservative option, log it under 'Deviations', and keep going."

### After implementation ("shipping means other people inheriting your unknowns")

10. **The buy-in doc** — pitch doc for stakeholders with zero session context. "90-second read" badge; sections: Watch it work (animated demo, replay) → The pitch → What reviewers will ask (objection → evidence pairs) → Spec at a glance → Risk, rollback, and what I need from you (named sign-offs). Export-selected button.
11. **Quiz me before I merge** — verification artifact. Change report (mental model, before/after cards, "non-obvious behaviors this introduces", file-path chips) ending in a scored multiple-choice quiz. Pass state "Cleared to merge"; fail state links back to the sections skimmed. "The artifact won't let you feel done until you actually are."
    > "I want to make sure I understand everything that happened in this change before I merge. Give me an HTML report on the diff — context, intuition, what was done — with a quiz at the bottom that I must pass."

## House frame (visual chrome shared by all eleven)

Warm ivory page (`#FAF9F5`); white cards, 1.5px gray borders, 14px radius; clay-orange accent (`#D97757`); olive success state (`#788C5D`); serif display headings; mono uppercase eyebrow labels. Top of page: eyebrow + H1 + one-sentence lede stating the principle, then a **prompt card** (mono "THE PROMPT" label, italic serif blockquote of the exact prompt, copy button that turns olive on click). Artifact content below a divider. All eleven patterns have live reference templates implementing this frame: `21-unknowns-map` (blindspot pass), `22-deviation-log` (implementation notes), `23-buy-in-doc` (pitch), `24-pre-merge-quiz` (change quiz), `25-interview`, `26-tweakable-plan`, `27-semantics-map` (reference port), `28-design-directions` (fan-out), `29-toolbar-mock` (mock before you wire), `30-brainstorm` (option space), `31-teach-me-explainer`.

## How this connects to the main thesis

HTML artifacts are the surface; unknowns are what you use the surface to hunt. Explainers surface vocabulary unknown-unknowns; fan-outs surface taste the user can't articulate; interviews surface known-unknowns by blast radius; deviation logs capture map-vs-territory gaps mid-build; buy-in docs and quizzes handle the final unknowns — other people, and your own skimming. Every artifact ends by making the next prompt one click to compose.
