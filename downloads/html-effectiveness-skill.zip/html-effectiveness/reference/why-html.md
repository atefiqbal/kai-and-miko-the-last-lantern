# Why HTML

A reference for future Claude sessions on why HTML beats markdown as an agent output format. Distilled from Thariq Shihipar's essay "The Unreasonable Effectiveness of HTML" (Claude Code team). Read this before deciding what format to write a plan, spec, report, or interface in.

---

## The Thesis

HTML keeps the human in the loop with the agent's work. Markdown was fine when plans were short and people still edited them by hand. They're not short anymore. Past about a hundred lines a markdown file stops being read — by you, and definitely by anyone else in your organization. Specs become walls of bullet points that scroll forever, and the moment a plan stops being read in depth is the moment you stop steering.

HTML is the format that survives the scale at which agents now work: richer information per token, visual hierarchy that the eye actually parses, shareable as a link, and interactive enough that the document itself becomes a tool you can talk back to. That last part is the whole point. The reason to use HTML is not aesthetics. It's that it pulls the user back into the loop.

There's also a quieter shift behind this. Most plan and spec files now live in a one-sided relationship: the agent writes them, the human glances. You're not actually editing the markdown anymore — when something needs to change, you prompt the model to change it. The instant that's true, markdown's biggest historical advantage (easy hand-editing) evaporates, and the only honest question left is which format the human is more likely to actually look at. HTML wins that question.

---

## The 8 Information Densities HTML Carries

HTML can represent almost any kind of information Claude can read. Markdown can represent maybe two of these well.

| # | Density | Carrier | One-line example |
|---|---|---|---|
| 1 | **Tables** | `<table>` rows & columns | A real comparison grid of 6 onboarding variants with tradeoff columns. |
| 2 | **Design** | CSS — color, type, spacing | A spec page that visually distinguishes "must do" from "consider" with color and weight. |
| 3 | **Illustrations** | inline SVG | A token-bucket diagram next to the rate-limiter explanation. |
| 4 | **Code** | `<pre><code>` + syntax highlighting via `<script>` | A highlighted diff with margin annotations the GitHub diff view can't render. |
| 5 | **Interaction** | sliders, toggles, JS + CSS | A "tune the easing curve, then copy params" prototype. |
| 6 | **Workflows** | SVG + HTML | Boxes, arrows, swimlanes for data flow through a feature. |
| 7 | **Spatial** | `<canvas>` + absolute positioning | A draggable Now/Next/Later/Cut triage board. |
| 8 | **Images** | `<img>` | Embedded screenshots and figures sitting next to the explanation, not below it. |

When HTML isn't available, the model reaches for sad substitutes — ASCII diagrams and (a personal favorite) unicode characters used to approximate color. That should tell you the model is already trying to escape markdown; the right move is to let it.

A useful test before writing: scan the list above. If even one of those eight densities would make your output materially clearer — a real table instead of pipe-syntax fakery, a real SVG flowchart instead of arrows-and-boxes ASCII, an actual color-coded severity legend, anything draggable, anything tunable — that's the signal to reach for HTML. If none of them apply (a four-line answer, a config edit, a commit message), markdown is fine.

---

## The 6 Motivations

### Information Density

HTML can convey much richer information than markdown. Headers and formatting, sure, but also tables, color, diagrams, syntax-highlighted code, sliders, flowcharts, canvases, images — all in a single file. There is almost no set of information Claude can read that you cannot fairly efficiently represent in HTML. That makes it a high-bandwidth channel both ways: the model can pack more idea per token of output, and you can review more idea per second of reading. In the absence of this, the model does inefficient things — ASCII diagrams, unicode color swatches — to fake what HTML would give for free.

### Visual Clarity & Ease of Reading

As Claude does more complex work, it writes larger and larger specs and plans. In practice, I do not actually read more than a 100-line markdown file. And I certainly cannot get anyone else in my organization to read it. HTML documents are much easier to read. Claude can organize structure visually — tabs, illustrations, links, mobile-responsive layout — so the same content is structured for reading instead of scrolling. The content didn't change. The likelihood that anyone reads it did.

### Ease of Sharing

Markdown files are hard to share. Most browsers don't render them natively, so you end up attaching them to emails or messages like it's 2008. HTML, as long as you upload it somewhere (S3, a static host, anywhere), is a link. Your colleagues open it wherever they want and reference it without thinking about format. The chance someone actually reads your spec, report, or PR writeup is much, much higher when it's a link they click than a file they download.

### Two-way Interaction

HTML can let you interact with the document. Add sliders to tune a design. Add knobs to swap algorithm parameters. Add a button that copies your changes back into a prompt to paste into Claude Code. The document stops being a deliverable and becomes a small, single-use instrument. Tune in the browser, paste the result back into the agent. This is the loop markdown cannot close.

### Data Ingestion

Why use Claude Code to make HTML instead of ClaudeAI or Claude Design? The context Claude Code can ingest. It can read your code folder, your git history, your MCP-connected tools (Slack, Linear, etc.), your browser via Claude in Chrome — and turn that pile of context into one HTML file that holds the synthesis. The diagrams in the source essay were generated this way: Thariq asked Claude Code to read through all the HTML files he'd ever generated, group and categorize them, and produce a single HTML file with diagrams for each type. That's not something a sandboxed artifact tool can do.

### It's Joyful

Making HTML documents with Claude is just more fun and makes me feel more involved and invested in the creation. That, by itself, is enough.

Don't underweight this. The reason you don't read 200-line markdown plans isn't only that they're long — it's that they're joyless. Joy is a real engineering input on whether the human stays engaged. An artifact that's pleasant to open is an artifact that gets opened. An artifact that's pleasant to share is an artifact that gets shared. Everything downstream of that — review quality, alignment, the agent actually getting useful corrections — depends on the human staying interested enough to look.

---

## The "Web of HTML Files" Workflow

When starting a real problem, do not write one markdown plan. Build a **web of HTML files** across stages. Each stage is its own artifact, and the next stage reads the previous ones as context.

> 1. Start by asking Claude Code to brainstorm and create some explorations of different options
> 2. Ask it to expand more into one, maybe make mockups or code snippets
> 3. When I feel good, ask it to write an implementation plan
> 4. When I'm happy with the plan, create a new session and pass in all of these files for it to implement

When verifying, also ask the verification agent to read in the files — it will have much broader context on what is actually needed.

The compounding value here is the artifact trail. Each file is small enough to read, but together they hold the full reasoning of how the team got from "I don't know what to build" to "build this." A markdown plan throws away the explorations. The web keeps them.

Notice the implicit rule in step 4: **fresh session for execution.** The implementing session does not need the brainstorming context bloating its window — it needs the artifacts, which are denser and cleaner than the conversation that produced them. The web of HTML files is also the handoff format. That's not incidental. A well-built HTML artifact is the unit of work between sessions, between people, and between you and the next version of yourself who comes back to this in two weeks.

---

## The "Copy as Prompt" Bidirectional Loop

This is the first-class pattern that separates HTML artifacts from PDFs and slides: **every editor UI ends with an export.**

A "copy as JSON" button. A "copy as prompt" button. A "copy diff" button. A "copy as markdown" button. Whatever shape the data wants to come out in — the artifact ends by turning the user's interaction back into something pasteable into Claude Code.

This closes the loop. The agent gives you a document. You manipulate it in the browser using affordances text could never give you (drag cards, drag sliders, click swatches, drag-drop ordering). Then you export the result of that manipulation as a prompt and feed it back to the agent. The HTML artifact is, in effect, a one-off GUI you spun up for one piece of data, used once, and discarded. **Not a product, or a reusable tool, but a single HTML file, purpose-built for this one piece of data.** That's the move.

If you build an HTML editor without an export button, you built a deliverable. If you build one with an export button, you built an instrument.

The shape this takes in practice: "copy as JSON" for structured data, "copy as prompt" for next-step instructions to Claude, "copy diff" for change sets, "copy as markdown" for human-readable output. The button text is small and the implementation is trivial — but its presence is what turns ten minutes of dragging cards around into a clean handoff back to the agent. Without that button, the user is stuck retyping their decisions into chat. With it, the loop closes in a single click.

---

## Use Cases Catalog

Thariq's five buckets, with his example prompts kept verbatim because they read like the work of someone who has actually done this hundreds of times. The shape of these prompts is the lesson — copy the shape.

### 1. Specs, Planning & Exploration

HTML is a rich canvas for Claude to dive into a problem. Instead of a simple markdown plan, expect to make a web of HTML files: explorations → expand one → mockup → implementation plan → fresh session for execution.

> I'm not sure what direction to take the onboarding screen. Generate 6 distinctly different approaches — vary layout, tone, and density — and lay them out as a single HTML file in a grid so I can compare them side by side. Label each with the tradeoff it's making.

> Create a thorough implementation plan in a HTML file, be sure to make some mockups, show data flow and add important code snippets I might want to review. Make it easy to read and digest.

Use for: exploring multiple code approaches; exploring multiple visual designs.

### 2. Code Review & Understanding

Code is hard to read in markdown. With HTML you can render real diffs with margin annotations, color-code findings by severity, embed flowcharts, link modules. Often beats the default GitHub diff view. Worth attaching an HTML explainer to every PR.

> Help me review this PR by creating an HTML artifact that describes it. I'm not very familiar with the streaming/backpressure logic so focus on that. Render the actual diff with inline margin annotations, color-code findings by severity and whatever else might be needed to convey the concept well.

Use for: creating a PR, reviewing a PR, understanding a topic in code.

### 3. Design & Prototypes

Claude Design is based on HTML because HTML is incredibly expressive at design — even if your end surface is React, Swift, or anything else. Sketch in HTML, port later. Prototype interactions with sliders and knobs so you tune in the exact values, then copy them back.

> I want to prototype a new checkout button, when clicked it does a play animation and then turns purple quickly. Create a HTML file with several sliders and options for me to try different options on this animation, give me a copy button to copy the parameters that worked well.

Use for: design system artifacts; adjusting components; visualizing component libraries; prototyping joyful animations.

### 4. Reports, Research & Learning

Claude Code is incredibly good at synthesizing information across multiple data sources — codebase, git history, Slack, Linear, the web — and turning it into a readable report. Long HTML doc, interactive explainer, or slide deck. SVG for diagrams.

> I don't understand how our rate limiter actually works. Read the relevant code and produce a single HTML explainer page: a diagram of the token-bucket flow, the 3–4 key code snippets annotated, and a "gotchas" section at the bottom. Optimize it for someone reading it once.

Use for: summarizing how a feature works; explaining a concept; weekly status reports to leadership; incident reports; SVG illustrations, flowcharts, and technical diagrams.

### 5. Custom Editing Interfaces

Sometimes it's hard to describe what you want purely in a text box. Ask Claude to build a **throwaway editor** for the exact thing you're working on. Not a product. Not a reusable tool. A single HTML file, purpose-built for this one piece of data. Always end with an export button.

> I need to reprioritize these 30 Linear tickets. Make me an HTML file with each ticket as a draggable card across Now / Next / Later / Cut columns. Pre-sort them by your best guess. Add a "copy as markdown" button that exports the final ordering with a one-line rationale per bucket.

> Here's our feature flag config. Build a form-based editor for it, group flags by area, show dependencies between them, warn me if I enable a flag whose prerequisite is off. Add a "copy diff" button that gives me just the changed keys.

> I'm tuning this system prompt. Make a side-by-side editor: editable prompt on the left with the variable slots highlighted, three sample inputs on the right that re-render the filled template live. Add a character/token counter and a copy button.

Use for: reordering, triaging, bucketing (tickets, test cases, feedback); editing structured config with constraints; tuning prompts and templates with live preview; curating datasets, tagging examples, exporting selections; annotating documents, transcripts, or diffs; picking values painful to express in text (colors, easing curves, crop regions, cron schedules, regexes).

The deeper pattern across all five buckets: **the artifact's job is to make the next prompt easier to write.** Explorations let you point and say "this one, expand it." Code-review HTML lets you point and say "the streaming logic in part 3 is wrong, fix it." Prototype sliders let you tune in values and paste them back. Reports let you point at a section and say "go deeper here." Editors let you do the work in the UI and copy the result. The HTML is not the deliverable. The next prompt is the deliverable, and HTML is the surface that makes it cheap to compose.

---

## FAQ

### Isn't it less token efficient?

Yes, markdown often uses fewer tokens. But the added expressiveness of HTML and the much higher likelihood that I actually read it means I get overall better output. With a 1M context window in Opus 4.7, the increased token usage is not really noticeable in the context window. Tokens are cheap. Unread plans are expensive.

### When do you still use markdown?

I've honestly stopped using markdown altogether for almost everything — but I'm probably far on the HTML maximalist side. Reasonable people keep markdown for: short inline answers, code comments and docstrings, git commit messages, CLAUDE.md and README.md (config-style files Claude reads as plain text).

### How do I view the HTML file?

Open it in a browser locally (you can ask Claude to open it). Or upload to S3 if you want a shareable link. That's it.

### Doesn't this take longer to generate than markdown?

Yes — 2-4x longer than markdown. Worth it. You're paying generation time once and reading-comprehension dividends forever. If the output isn't going to be read again, write markdown. If it is, eat the latency.

### What about version control?

Honestly one of the biggest downsides. HTML diffs are noisy and hard to review compared to markdown. If a file lives in git and will be reviewed via PR diffs, consider markdown. If it lives on S3 or a static host and gets regenerated, HTML wins.

### How do I get Claude to match my taste / not make it ugly?

The frontend design plugin helps Claude make good-looking HTML. To match your company's style specifically, create a single design-system HTML file by pointing Claude at your codebase. Then use that file as a reference when generating new HTML — Claude reads the design system, matches the tokens, types, and spacing, and the output stops looking generic.

The design-system file is one of the highest-leverage HTML artifacts you can build, because every subsequent artifact inherits its taste. Spend an afternoon on it once. Reference it for the next hundred outputs. The marginal cost of "make this look like us" drops to a single sentence in the prompt.

---

## Don't Over-Engineer This

A direct warning from Thariq, worth quoting in full because it's the single most common failure mode of reading this essay:

> I'm a little bit afraid that people will read this article and turn it into a /html skill or something. While there might be some value in that, I want to emphasize that you don't need to do much to get Claude to do this. **You can just ask it to "make a HTML file" or "make a HTML artifact".**

The trick is knowing what you want the artifact to do and how you might use it. Not the prompt scaffolding. Not a 12-step skill. Just: make a HTML file, here's what should be in it, end with a copy button if it's interactive.

Implication for this skill: invoke lightly. The skill exists to remind future sessions of the philosophy and the prompt shapes — not to wrap every "write a plan" request in ceremony. If the user says "draft a spec," the right move is usually to ask "want it as an HTML file?" and then produce a clean single-file artifact. Not to run a workflow.

The aggressive version of this rule: **the skill should feel like a tap on the shoulder, not a checklist.**

Concretely, that means: don't load this skill on every document request. Don't preface plans with five paragraphs of HTML philosophy. Don't insist on HTML when the user asked for a CLAUDE.md update, a git commit message, or a one-line inline answer. The skill exists to remind future sessions that when the output is going to be *read*, HTML is the default — and that the prompt shape is "make a HTML file that [does X], end with a copy button." That's it. The rest is taste.

---

## Where This Sits in the Workflow

A practical sequencing note for future sessions: this reference is the *philosophy*, not the *workflow*. The flow when actually doing real work looks like:

1. **Decide format.** Is this output going to be read more than once, shared, or interacted with? If yes → HTML. If no → markdown.
2. **Choose the artifact type.** Single explainer page? Web of exploration files? Throwaway editor? Code review with annotated diff? The 5-bucket catalog above is the menu.
3. **Write the prompt.** Use the example prompts as the shape template. State the goal, the format, the must-include elements, and (if interactive) the export button.
4. **Generate, open, react.** The reaction — what you click, what you change, what you copy back into the next prompt — is the actual work product. The HTML file is the surface that made the reaction cheap.
5. **Carry the artifact forward.** Pass it into the next session as context. Don't summarize it into chat. The artifact is denser and cleaner than your retelling.

That cycle is the loop. Everything in this reference is in service of running it efficiently.

---

## Common Failure Modes

Even teams already sold on HTML output trip on the same handful of mistakes. Watch for these:

- **Building a product instead of an artifact.** The editor is throwaway. One HTML file, one piece of data, one session. The moment you start thinking about reusability, you've lost the plot. Make it ugly if it's faster.
- **Forgetting the export button.** An interactive HTML page with no way to get the result back out is a dead end. Every editor ends with copy-as-something.
- **Treating HTML as a styling task.** The point isn't pretty — it's *readable*. Visual hierarchy, navigability, density per scroll. A clean black-on-white layout with a clear table beats a gradient-rich design with bad information architecture, every time.
- **Defaulting to markdown out of habit on long outputs.** A 300-line markdown plan is the thing the essay warns about. If you catch yourself writing one, stop and ask if HTML would survive better.
- **Generating HTML when the user just wanted three sentences.** Inverse failure mode. The skill is a default for read-once-or-more artifacts, not a mandate. Don't wrap "yes, that's correct" in a styled file.
- **Skipping the design-system reference and producing generic-looking HTML.** If the company has visual taste, pointing at the design-system file in every prompt costs nothing and removes the "this looks AI-generated" tax.

---

## Stay in the Loop

The deepest reason to use HTML isn't density, sharing, or interaction. It's that HTML makes the user feel involved in agent-driven work.

> All of the above is to say that I think the real reason I use HTML is that I feel much more in the loop with Claude. I had begun to fear that because I had stopped reading plans in depth I would simply have to leave Claude to make its choices. But I am happy to say instead that I feel more in the loop than ever before when using HTML.

That's the whole skill. When you reach for HTML over markdown, you are choosing a format that the human will actually look at, click around in, and push back on. Markdown is a one-way broadcast at the size agents now operate. HTML is a conversation. The agent gets smarter; the human stays in the loop. That's the trade you're making, every time.

A working summary you can hold in your head while deciding format on the fly:

- If the output is meant to be **read**, default to HTML.
- If the output is meant to be **edited by hand**, markdown is fine.
- If the output needs to be **shared with someone else**, HTML by a wide margin.
- If the output needs to be **interactive** in any way — sliders, drag-drop, live preview — HTML is the only option that makes sense.
- If the output will be **referenced again later as context for a new session**, HTML, and end it with an export button.
- If it's a CLAUDE.md, a commit message, a code comment, or a four-line inline answer — keep markdown and move on.

Nothing in this reference is a rule. It's a set of defaults the Claude Code team has converged on after watching what actually gets read, shared, and acted on. The goal is not "use HTML for everything." The goal is to stay in the loop. HTML is just the format that, more often than not, makes that possible at the scale agents now operate.

---

*Source: Thariq Shihipar, "Using Claude Code: The Unreasonable Effectiveness of HTML."*

*Repo & examples: [github.com/thariqs/html-effectiveness](https://github.com/thariqs/html-effectiveness)*

*Live gallery: [thariqs.github.io/html-effectiveness](https://thariqs.github.io/html-effectiveness)*

*This reference distills Thariq's essay into a fast-lookup format for future Claude sessions in this skill. Treat his exact phrases ("web of HTML files", "throwaway editor", "stay in the loop", "make a HTML file or a HTML artifact") as load-bearing — they are the handles by which the philosophy gets reapplied without ceremony.*
