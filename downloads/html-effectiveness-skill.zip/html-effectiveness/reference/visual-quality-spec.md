# Visual quality spec — the design contract

Extracted from full-page screenshots of all 31 of Thariq Shihipar's canonical artifacts (`assets/screenshots/`). This is what "finished" looks like. **Before writing any artifact, view the matching screenshot** (`assets/screenshots/main-NN-*.jpg` or `unknowns-NN-*.jpg`) with the Read tool — one look transfers more than any spec. Then hold every rule below.

## The meta-pattern (all 31 artifacts do these four things)

1. **Echo the prompt or state scope.** A tinted card near the top quotes the originating ask (mono `PROMPT`/`THE PROMPT` label, italic serif body, copy button) — or the lede states limits honestly ("Throwaway HTML… ~40 lines of JS, no libraries", "MOCK, NO REAL CODE TOUCHED").
2. **Render live, don't describe.** Real buttons, real bar charts, real diffs, working sliders with readouts, actual CSS specimens — never a prose description or image of a thing HTML can just *be*.
3. **End with a decision.** Recommendation callout, suggested next steps with checkboxes, open questions, "tweak these three things", improved prompt, CTA banner with deadline. The artifact's last section converts reading into the next action.
4. **Make everything extractable.** Copy-paste CSS blocks, Download SVG per figure, copy diff / copy reply / copy prompt buttons. Primary action = solid near-black pill, white text; secondaries outlined.

## Palette (the "Acme" token set — exact)

- Page: warm ivory `#FAF9F5`. Cards: `#FFFFFF`, 1px–1.5px hairline borders `#DDD8CE`/`#e4e0d8`, radius 6–14px. Panel tint `#F0EEE6`; tan/oat insets `#EDE9DC`/`#E3DACC` for mono snippets and neutral banners.
- Ink: near-black warm `#141413`/`#1E1C1A`. Muted text `#87867F`.
- **One loud accent: clay/terracotta `#D97757`** (range `#C15F3C`–`#E8663C`). Used ONLY for meaning: the thing in focus, deviations, blockers, active states, section numerals, prompt labels, weakest-part callouts.
- Semantic support (all desaturated, earthy): olive `#788C5D` = success/done/confirmed; ochre `#C78E3F` = warning; muted red `#B04A4A` = danger; slate-blue `#5C7CA3` = info/discovery.
- Code blocks: one dark charcoal surface `#262625` (never pure black) with restrained syntax color (clay keywords, olive strings, warm-gray comments). Light-beige code variant for config snippets in side panels.
- **Never:** gradients, drop shadows (hierarchy = border + tint, not elevation), pure black/white page, default-blue links, emoji, stock icons, more than one loud hue.

## Typography (three strict roles)

- **Serif** (Georgia/Tiempos feel) = "for humans": H1 ~32–40px regular weight (never bold serif), section headings ~20–24px, card titles ~17–18px, prose, and *italic serif for quoted prompts and reply templates*.
- **Mono ~10–13px UPPERCASE letterspaced muted** = "machine/metadata": every eyebrow, label, tag, chip, table header, file path, timestamp, footer, SVG box label. This is the single most identifying trait — labels are never bold sans, always small caps-mono.
- **Sans** ~14–16px/1.55 = explanation: body copy, captions, table cells.
- Inline code = mono on a faint tan pill, everywhere an identifier appears. Mono-in-serif titles are embraced ("What happens when you `git push`").

## Document chrome (both ends)

- **Header anatomy (invariant):** mono eyebrow (context · category, e.g. `PULL REQUEST · ACME`) → serif H1 → 1–3 line sans lede → mono meta line or chip row (`9 files +418/−190 · branch · author`, SEV pills, `● 90-second read`).
- **Stat strip** right under the header when numbers exist: 3–4 boxed cards, big serif numeral (~36px) over caps-mono label + tiny delta line; the attention-worthy stat gets clay.
- **Metadata chrome:** faux window bars (three dots + mono breadcrumb) around embedded mocks and scan reports; run windows (`run started 14:02 · last write 16:51`).
- **Sticky mini-TOC** in a margin rail for long reads: mono `ON THIS PAGE` / `IN THIS PR` / `FILES READ` / `GLOSSARY` — the evidence trail is first-class UI.
- **Footer provenance:** one mono ~11px muted line: `Sources: git log main..HEAD · CI dashboard — generated <date>` + pattern attribution.

## Card anatomy — labeled micro-rows (the signature move)

Never flatten a card into one paragraph. Decompose into small caps-mono labeled rows:
- Blindspot cards: typed tag (`Landmine`/`Convention`/`History`/`Missing concept`) + index `01…07` → body → `WHY IT BITES` row (clay left bar) → copyable prompt-fix snippet with its own COPY button.
- Deviation entries: `WHAT THE PLAN SAID / WHAT THE CODE REVEALED / CONSERVATIVE CHOICE / REVISIT` — always that order, clay-left-bordered inset.
- Behavior cards: `WHAT / WHY / WHERE` rows, WHERE holding `file.ts:41` mono chips.
- Idea cards: `FOUND IN CODE —` (evidence with real paths) + `IMPACT` rows, size badge (S/M/L/XL) top-right.
- Left-border semantics: 3–4px colored bar encodes meaning (clay=deviation/risk/callout, olive=confirmed/needs-from-you, slate=discovery, neutral=collapsed).

## Density — lived-in, not sketched

Canonical artifacts carry **7–11 items**, timestamps, PR numbers (`#2841`), `file.ts:line` chips, `§4.2` spec refs, named people with roles and initial-avatars, diffstat numbers, dates. 2–4 clean-but-thin items reads as AI filler. Every card cites at least one file path, one identifier, and one dated/numbered event. Deliberate omissions are declared ("No auto-scroll. Left out on purpose."), collapsed sections show counts (`▸ Boring but necessary — 8 tasks · ~0.5d`).

## SVG & diagrams

Geometric-but-warm: flat fills only (ivory/oat/clay/olive), rects `rx="10"`, 1.5px gray strokes (2px slate for emphasized), mono ~11px labels INSIDE boxes, sans ~12px annotations outside. Thin gray arrows with small solid heads; **failure/async paths = dashed clay**; edge labels tiny mono (`pass`, `cookie`, `+1s/+2s/+4s`). Focus node = clay stroke + faint clay fill. Legend strip below the canvas. Before/after architecture = paired vertical node stacks with ↓ arrows, new nodes clay-outlined `(new)`, deprecated tinted tan. Each standalone SVG carries its own `<style>` and a Download button.

## Interaction affordances

- Buttons: small rounded-rect/pill, mono labels; ONE primary per zone = solid near-black; copy buttons flip to olive "Copied" ~1.5s.
- Chips: pill, caps-mono ~9–11px, tinted bg + darker same-hue text; selected = solid near-black fill white text; semantic prefix style `steal ✓ · the 4-stat metric strip`.
- Reaction affordances fill a reply builder: chips/checkboxes/radio rows write into a tan mono block with placeholder `___ (tap a chip above)` in clay; sticky bottom export bar (dark, count + `copy reply`) for long lists.
- Toggles = pill switches (olive on); tabs = flat beige strip, active white; live counters in bordered mono chips (`373 chars · ~89 tokens`); mono hint lines (`› drag tickets between columns`).
- Every visual encoding is captioned somewhere ("Anything underlined in dashed clay isn't a known field…").
- Dark inversion used exactly ONCE per document as the emphasis mechanism (TL;DR card, decision slide, demo player).

## Spacing

Content column ~640–1000px centered, huge ivory margins; sidebar layouts ~2:1. Section gaps 64–96px, card padding 20–28px. Serif section headings often carry a full-width hairline rule. Whitespace is the layout system — hairline + whitespace, never boxes-in-boxes.

## Screenshot index

`assets/screenshots/main-01…20` = the 20 main patterns (matching `reference/NN-*.html` numbers, 06 missing from capture set); `unknowns-index` + `unknowns-01…11` = the Know Your Unknowns set (01 blindspot→our 21, 09 implementation notes→our 22, 10 pitch doc→our 23, 11 change quiz→our 24). View the closest one before writing. If the archetype has no screenshot, view the two nearest neighbors and hold the DNA above.
