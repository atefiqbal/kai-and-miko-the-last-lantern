# eval-cases.md — html-effectiveness skill eval suite

How to use: run a fresh session against each prompt, grade against Expected. Fire/skip is binary. Archetype match is graded loose — structural adaptation counts; verbatim copy of a reference file is a **fail** (anti-pattern).

## 1. Trigger evals

| # | User prompt | Expected | Archetype (reference/) | Must-have elements |
|---|-------------|----------|------------------------|--------------------|
| T1 | "Draft an implementation plan for migrating our API cache to Redis" | **FIRE** | `16-implementation-plan` | Single `.html` file, phased timeline, SVG data-flow diagram, code snippets, gotchas section |
| T2 | "Compare these 3 auth approaches side by side — JWT, sessions, PASETO" | **FIRE** | `01-exploration-code-approaches` | Comparison grid, pros/cons per option, labeled tradeoffs, code snippets |
| T3 | "I'm not sure what direction to take the pricing page. Help me decide between these." (vague) | **FIRE** — vagueness is not a skip signal; "decide between" = comparison | `02-exploration-visual-designs` or `01` | 4–6 distinct options in a grid, each labeled with the tradeoff it makes |
| T4 | "What don't you know about this task? What assumptions are you making?" | **FIRE** | Unknowns map (no numbered reference — write fresh, reuse 16/18 chrome) | Assumptions with confidence, open questions with defaults, blockers; "copy answers as prompt" button |
| T5 | "Did you deviate from the plan? Show me where." | **FIRE** | Deviation log (write fresh) | Planned→actual→why rows, severity colors, per-row keep/revert verdict, "copy verdicts as prompt" |
| T6 | "I need to reprioritize these 20 tickets — let me drag them into buckets" | **FIRE** | `18-editor-triage-board` | Draggable cards, Now/Next/Later buckets, **copy-as-markdown export button** — fail if absent |
| T7 | "Write the commit message for this change" | **SKIP** — commit messages stay plain text | — | Response in chat, no file created |
| T8 | "Update the README with the new install steps" | **SKIP** — README edits stay markdown | — | Edits `README.md` only, no HTML artifact |
| T9 | "What port does the dev server run on?" (3-line answer) | **SKIP** — fits in chat | — | Short chat reply, no file |
| T10 | "Write a migration plan **in markdown** — I need it for our wiki" | **SKIP** — explicit format override beats the default | — | Markdown output; may note HTML is available, but do not produce it unasked |
| T11 | "Weekly update for the team on the checkout project" | **FIRE** | `11-status-report` | Status colors (on-track/at-risk), progress vs. plan, blockers section |
| T12 | "Explain how the streaming backpressure code works, I'm not familiar with it" | **FIRE** | `04-code-understanding` | Call-graph SVG, entry points, key types, annotated snippets — **no ASCII diagrams** |

## 2. Mechanical smoke-test checklist

Run against any generated artifact `$F`:

```sh
test -f "$F"                                              # single file exists
grep -qi '<!doctype html>' "$F"                           # doctype present
grep -qi '<title>' "$F"                                   # has title
grep -qi 'name="viewport"' "$F"                           # viewport meta
grep -qi 'charset="utf-8"' "$F"                           # charset
! grep -Eqi '<(script|link|img)[^>]+(src|href)="https?://' "$F"   # no remote resource loads (data: URIs OK)
! grep -Eq '@import\s+url\(.?https?://' "$F"              # no remote CSS imports
grep -q '<svg' "$F" || ! grep -Eq '(\+--|-->\s*$|┌|└|─)' "$F"     # diagrams are SVG, not ASCII/box-drawing
# If artifact is an editor (T4, T5, T6, proof P2):
grep -Eqi 'navigator\.clipboard|copy.?(as|to).?(prompt|markdown|json|clipboard)' "$F"   # export handler present
```

All assertions must pass. Bonus (manual): file opens from `file://` with no console errors; layout survives 375px viewport. Then run `reference/artifact-rubric.md` fast pass.

## 3. Proof prompts

**P1 — Unknowns map:** "Before you start the Stripe webhook refactor: give me an unknowns map as an HTML file. Every assumption you're making, every open question, ranked by how badly a wrong guess would hurt. Add how each one gets resolved and by whom."
- Fires with a single self-contained HTML file; unknowns grouped by severity with color coding, not a flat list
- Each item has assumption vs. question type, blast-radius rating, a concrete resolution path, and an answerable control (radio/short text)
- Ends with a "copy answers as prompt" button; passes all section-2 shell checks

**P2 — Editor with export:** "I'm tuning the system prompt for our support bot. Build me a throwaway editor: editable prompt on the left with variable slots highlighted, three sample inputs on the right that re-render live, a token estimate, and a copy-as-prompt button."
- Live re-render works with vanilla JS only (no React/CDN); variables visually highlighted in the template
- Copy-as-prompt button copies the *tuned* template, not the page HTML — export-handler grep passes
- Single file, opens from disk, mobile-responsive; adapted from `20-editor-prompt-tuner` structure without verbatim copy

**P3 — Exploration grid:** "I don't know what direction to take the empty-state screen for the dashboard. Generate 6 distinctly different approaches — vary layout, tone, and density — laid out in one HTML grid so I can compare. Label each with the tradeoff it's making."
- Exactly 6 visually distinct options rendered *as designs* (real CSS/SVG mockups), not prose descriptions of designs
- Each cell carries a tradeoff label; options genuinely vary on the named axes rather than palette swaps of one idea
- One self-contained file passing section-2 checks; grid collapses gracefully at narrow widths

---
Scoring: T-cases are pass/fail on fire-decision, then graded 0–2 on archetype + must-haves. Smoke tests are hard gates. Proof prompts pass only if all 3 bullets hold. Footer attribution (`Pattern adapted from github.com/thariqs/html-effectiveness`) expected whenever a reference pattern was adapted.
