# html-effectiveness — reference manifest

31 self-contained HTML patterns (20 from `github.com/thariqs/html-effectiveness`, 11 trust artifacts built from his "Know Your Unknowns" follow-up — full parity with that index), plus the original landing page. Each file is a complete, viewable document — open in a browser to see the pattern in action before adapting it.

| # | File | Category | Use when… |
|---|------|----------|-----------|
| — | `index.html` | Landing | Picking a pattern when unsure — Thariq's overview/gallery |
| 01 | `01-exploration-code-approaches.html` | Exploration & Planning | Comparing 2–4 code approaches side-by-side with pros/cons |
| 02 | `02-exploration-visual-designs.html` | Exploration & Planning | Comparing visual design options visually, not in prose |
| 03 | `03-code-review-pr.html` | Code Review | Annotating a PR diff inline with reviewer commentary |
| 04 | `04-code-understanding.html` | Code Review | Walking a reader through an unfamiliar module — call graph, key types, entry points |
| 05 | `05-design-system.html` | Design | Documenting design tokens — colors, type scale, spacing, radii |
| 06 | `06-component-variants.html` | Design | Showing every state/variant of a component on one page |
| 07 | `07-prototype-animation.html` | Prototyping | Iterating on motion — easing curves, durations, choreography |
| 08 | `08-prototype-interaction.html` | Prototyping | Clickable flow before committing to engineering |
| 09 | `09-slide-deck.html` | Decks | Presenting in slides with keyboard nav, no PowerPoint |
| 10 | `10-svg-illustrations.html` | Diagrams | Hand-drawn-feel SVG figures to explain a concept |
| 11 | `11-status-report.html` | Reports | Weekly / sprint / project status update |
| 12 | `12-incident-report.html` | Reports | Postmortem with timeline, root cause, action items |
| 13 | `13-flowchart-diagram.html` | Diagrams | Flowchart / sequence / state diagram — system behavior |
| 14 | `14-research-feature-explainer.html` | Research | Explaining a feature to a non-author audience |
| 15 | `15-research-concept-explainer.html` | Research | Teaching a concept from first principles — tutorial-style |
| 16 | `16-implementation-plan.html` | Exploration & Planning | Multi-phase implementation plan with timeline and milestones |
| 17 | `17-pr-writeup.html` | Code Review | Writing the human-readable summary that should accompany a PR |
| 18 | `18-editor-triage-board.html` | Custom Editor | Kanban / triage board the user can edit in-place |
| 19 | `19-editor-feature-flags.html` | Custom Editor | Feature-flag toggle UI with preview |
| 20 | `20-editor-prompt-tuner.html` | Custom Editor | Prompt-tuning UI with variables, preview, copy-out |
| 21 | `21-unknowns-map.html` | Trust Artifact | Surfacing assumptions/questions before ambiguous work — confidence, blast radius, answer chips, copy-answers-as-prompt |
| 22 | `22-deviation-log.html` | Trust Artifact | Implementation notes during a build — plan-vs-actual, per-row keep/revert verdicts, copy-verdicts-as-prompt |
| 23 | `23-buy-in-doc.html` | Trust Artifact | Stakeholder pitch doc — demo first, objection→evidence pairs, named sign-offs, copy-decision |
| 24 | `24-pre-merge-quiz.html` | Trust Artifact | Change report ending in a scored quiz — fail links back to skimmed sections, pass unlocks "cleared to merge" |
| 25 | `25-interview.html` | Trust Artifact | One-question-at-a-time spec interview ordered by blast radius — ends in decisions table + copy-implementation-prompt |
| 26 | `26-tweakable-plan.html` | Trust Artifact | Plan sorted by likelihood-of-tweaking — toggleable alternatives, weakest-part callout, mechanical work collapsed |
| 27 | `27-semantics-map.html` | Trust Artifact | Proof-of-understanding before porting a reference — matched code pairs, gotcha notes, edge-case table, confirm/correct |
| 28 | `28-design-directions.html` | Trust Artifact | Same data, 4 wildly different live designs — steal/skip chips assemble your reply |
| 29 | `29-toolbar-mock.html` | Trust Artifact | Clickable throwaway mock with fake data before real code — placement tabs, A/B questions, self-filling reply |
| 30 | `30-brainstorm.html` | Trust Artifact | 10 codebase-grounded interventions cheapest→most ambitious — resonate checkboxes, sticky copy-reply bar |
| 31 | `31-teach-me-explainer.html` | Trust Artifact | Interactive domain explainer with vocabulary ladder + live demo — ends with prompts you couldn't write an hour ago |
| — | `why-html.md` | Philosophy | Read once to internalize the *why* behind every pattern above — Thariq's essay distilled |
| — | `unknowns-workflow.md` | Philosophy | The 11 "Know Your Unknowns" patterns with verbatim prompts — specs for blindspot pass, interview, tweakable plan, buy-in doc, pre-merge quiz |
| — | `visual-quality-spec.md` | Quality | Binding design contract from screenshots of all canonical artifacts — palette, typography roles, card anatomy, density, meta-pattern |
| — | `artifact-rubric.md` | Quality | Pre-delivery self-review checklist — run the fast pass on every artifact |
| — | `eval-cases.md` | Quality | Trigger evals + mechanical smoke tests — use when testing changes to this skill |

## How to choose

1. Read the user's ask. Note the *output verb*: "plan", "explain", "compare", "review", "diagram", "report", "present", "edit".
2. Match to the closest pattern row above.
3. If two patterns fit, prefer the more specific one. (e.g. "weekly update on incident XYZ" → 12 if the focus is the incident, 11 if the focus is the week.)
4. If nothing fits cleanly, open `index.html` and pick the closest visually.

## Provenance

These files are reproduced verbatim from `github.com/thariqs/html-effectiveness` (default branch, cloned `2026-05-17`). No upstream `LICENSE` file was present at clone time. Treat them as **reference material**, not redistribution. Credit Thariq Shihipar when adapting a pattern in a delivered artifact.
