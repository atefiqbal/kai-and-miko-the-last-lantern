# Artifact Self-Review Rubric

Run this checklist on every generated HTML artifact before delivering. Fix failures, then re-check. Each item is verifiable in under 10 seconds.

## Fast pass (minimum bar, every artifact)

- [ ] File opens from disk with zero network requests — no CDN scripts, remote fonts, or external stylesheets.
- [ ] `<title>` is set and describes this specific artifact.
- [ ] At 375px width nothing overflows the viewport; wide tables scroll inside their own container.
- [ ] Every button, tab, and toggle does something; copy buttons show visible "copied" feedback.
- [ ] No invented numbers — every metric traces to a real source or is marked as an estimate/unknown.

## 1. Self-containment & portability

- [ ] Zero external URLs in `src`, `href` (stylesheets), `@import`, or `fetch` — search the file for `http` to verify.
- [ ] Fonts are system stacks (`system-ui`, `ui-serif`, `ui-monospace`) — no Google Fonts links.
- [ ] All CSS and JS inline; no framework dependencies (React, Tailwind CDN, Chart.js — none).
- [ ] Images embedded as data URIs or inline SVG, never remote links.
- [ ] File starts with `<!doctype html>`, `<meta charset="utf-8">`, viewport meta, and a real `<title>`.
- [ ] Filename is short, kebab-case, descriptive — not `output.html` or `artifact.html`.

## 2. Readability & hierarchy

- [ ] No paragraph runs wider than ~70 characters per line; body text column is max-width constrained.
- [ ] No wall of text: any run of 4+ dense paragraphs is broken by a heading, table, card, or diagram.
- [ ] Scanning only headings and bolded phrases tells the whole story in 30 seconds.
- [ ] The most important fact appears in the first screenful, not buried at the bottom.
- [ ] Diagrams are SVG — no ASCII art or box-drawing characters inside `<pre>` or code fences.
- [ ] Unicode blocks (🟦🟩) are not standing in for color swatches — real CSS-colored chips only.
- [ ] Tables have real `<thead>`, left-aligned text, right-aligned numbers, and row separators.
- [ ] Length matches content: no padding sections, boilerplate caveats, or repeated summaries to look comprehensive.

## 3. Aesthetic sanity

- [ ] Body text contrast ≥ 4.5:1 against its background; no light-gray-on-white below 14px.
- [ ] No text sits directly on a gradient or image without a solid backing panel.
- [ ] Max two gradients in the whole file — zero is better; no purple-to-blue hero banners by default.
- [ ] Color palette is ≤ 6 hues total (neutrals excluded), defined once as CSS variables.
- [ ] Type scale has 3–5 sizes with clear jumps (e.g. 12/14/16/24/38) — not seven near-identical sizes.
- [ ] Body font size ≥ 14px; line-height 1.4–1.7 for running text.
- [ ] Spacing uses a consistent rhythm (multiples of 4 or 8px); sections separated by ≥ 40px.
- [ ] Border radius, border weight, and shadow style are each consistent across all cards/panels.
- [ ] No emoji unless the user's content explicitly invites them.
- [ ] Squint test: blurred, the page shows clear regions and hierarchy — not uniform decorated soup.

## 4. Interaction integrity

- [ ] Click every interactive element mentally: each button, tab, filter, and toggle has a working handler.
- [ ] No decorative dead controls — if it looks clickable, it works; if it can't work, restyle it as static.
- [ ] Every editor (triage board, tuner, flag panel) has a Copy/Export button — it's the point of the pattern.
- [ ] Copy buttons confirm success: label swap ("Copied"), color change, or both, reverting after ~1.5s.
- [ ] Copy/export output is complete and paste-ready (valid markdown/JSON/prompt), not a fragment.
- [ ] Collapsibles and tabs default to the state a first-time reader needs; nothing critical hidden by default.
- [ ] Drag-and-drop (if present) updates counts/state and survives a full reorder without console errors.
- [ ] JS is vanilla and inline; page still conveys its core content if JS fails entirely.

## 5. Honesty

- [ ] Every number, date, and name comes from provided data — nothing plausible-sounding invented to fill a cell.
- [ ] Placeholder or illustrative data is labeled as such ("sample", "illustrative") in-place, not just implied.
- [ ] Unknowns render as "Unknown" or "—" with a note — never silently guessed or zero-filled.
- [ ] Estimates and extrapolations are visually distinct from measured values (label, style, or footnote).
- [ ] Charts start axes honestly; no truncated y-axes that exaggerate small differences.
- [ ] Status/severity colors reflect actual state, not optimistic defaults (nothing green "by default").
- [ ] Claims of completeness are true: "all 30 tickets" means all 30 are in the file.
- [ ] If adapting a Thariq pattern, footer attribution present: `Pattern adapted from github.com/thariqs/html-effectiveness`.

**Rule of thumb:** if any section fails 2+ items, revise before delivering — don't ship and caveat.
