THE LAST LANTERN — PROMPT PACK
The working prompts behind a 45s AI-animated short (Kai & Miko challenge).
Pipeline: reference sheets -> 12 keyframes (GPT Image 2, 2K, refs locked) -> 3x15s Seedance 2.0 multishot -> edit/sound/VO.
Rule that makes it work: lock WHO (character sheets), WHERE (environment sheet), WHAT (object sheet) as image references BEFORE generating any shot. Pass those same references into every keyframe and every video generation.
